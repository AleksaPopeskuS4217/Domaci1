<?php

    $ime = $_GET['ime'];
    $prezime = $_GET['prezime'];
    $broj = $_GET['broj'];

    
    echo 'Ime:'.$ime;
    echo '<br>Prezime:'.$prezime;
    echo '<br>Broj indeksa:'.$broj;
?>
